import { site, categories, destinations } from './data.js?v=34218b3741';

export const escapeHtml = (value = '') => String(value).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
export const activeProducts = (products) => products.filter((p) => p.status === 'active');
export const availableVariants = (product) => product.variants.filter((v) => v.status === 'active' && v.images?.length);
export const findVariant = (product, id) => availableVariants(product).find((v) => v.id === id) || availableVariants(product).find((v) => v.id === product.defaultVariantId) || availableVariants(product)[0];
export const productPath = (product, variantId) => `/products/${encodeURIComponent(product.slug)}/${variantId ? `?color=${encodeURIComponent(variantId)}` : ''}`;
export const unitPriceCents = (product) => product.salePriceCents ?? product.priceCents;
export const sizeLabel = (product, size) => product.sizeDisplay?.[size] || size;

// A set lets the customer pick a different size for each piece. Single garments
// expose one group keyed 'single' so the same code path serves both.
export function sizeGroups(product) {
  const pieces = (product.pieces || []).filter((piece) => piece.sizeKey && Array.isArray(piece.sizes));
  if (!pieces.length) return [{ key: 'single', label: 'Size', sizes: product.sizes }];
  return pieces.map((piece) => ({ key: piece.sizeKey, label: piece.sizeLabel || piece.name, sizes: piece.sizes, piece }));
}

export const hasPieceSizes = (product) => sizeGroups(product).length > 1 || sizeGroups(product)[0].key !== 'single';

// Reads either the legacy `size` field or the per-piece `size_<key>` fields.
export function selectedSizes(product, values) {
  const result = {};
  for (const group of sizeGroups(product)) {
    result[group.key] = group.key === 'single' ? (values.size || '') : (values[`size_${group.key}`] || '');
  }
  return result;
}

export function sizeSummaryText(product, values) {
  const chosen = selectedSizes(product, values);
  if (!hasPieceSizes(product)) {
    const size = chosen.single;
    return size ? `Size ${sizeLabel(product, size)}` : 'Size not selected';
  }
  return sizeGroups(product).map((g) => `${g.label} ${chosen[g.key] ? sizeLabel(product, chosen[g.key]) : '—'}`).join(' · ');
}
export const clampQuantity = (value, max = 99) => Math.min(max, Math.max(1, Math.trunc(Number(value) || 1)));

export function shippingCents(product, countryCode = '') {
  const rate = product.shipping.ratesByCountry?.[countryCode];
  return rate ?? product.shipping.defaultRateCents ?? 0;
}

export function calculateTotals(product, quantity = 1, countryCode = '') {
  const qty = clampQuantity(quantity, product.maxQuantity);
  const unitCents = unitPriceCents(product);
  const productCents = unitCents * qty;
  const shipping = shippingCents(product, countryCode);
  return { quantity: qty, unitCents, productCents, shippingCents: shipping, totalCents: productCents + shipping };
}

export function formatMoney(cents, withCurrency = false) {
  const amount = (cents / 100).toFixed(2);
  return `${site.currencySymbol}${amount}${withCurrency ? ` ${site.currency}` : ''}`;
}

export function categoryMatches(product, categoryId) {
  if (!categoryId || categoryId === 'all') return true;
  const category = categories.find((c) => c.id === categoryId);
  if (category?.rule === 'new') return Boolean(product.badge && /new|just added/i.test(product.badge));
  return product.categories.includes(categoryId);
}

export function filterProducts(products, { query = '', category = 'all', sort = 'featured' } = {}) {
  const words = query.trim().toLocaleLowerCase().split(/\s+/).filter(Boolean);
  let result = activeProducts(products).filter((product) => {
    const haystack = [product.name, product.categoryLabel, product.subtitle, product.description, product.productType, product.fabric, product.material, ...product.tags, ...product.categories.map((id) => categories.find((c) => c.id === id)?.label || ''), ...availableVariants(product).map((v) => v.name)].join(' ').toLocaleLowerCase();
    // Word-prefix matching keeps short color words accurate: "red" must not match
    // "paired" or "flared". Hyphenated queries still match literally.
    const tokens = haystack.split(/[^\p{L}\p{N}]+/u).filter(Boolean);
    const matches = (word) => /[^\p{L}\p{N}]/u.test(word)
      ? haystack.includes(word)
      : tokens.some((token) => token.startsWith(word));
    return categoryMatches(product, category) && words.every(matches);
  });
  if (sort === 'price-asc') result.sort((a, b) => unitPriceCents(a) - unitPriceCents(b));
  if (sort === 'price-desc') result.sort((a, b) => unitPriceCents(b) - unitPriceCents(a));
  if (sort === 'name') result.sort((a, b) => a.name.localeCompare(b.name));
  if (sort === 'newest') result.sort((a, b) => String(b.addedAt).localeCompare(String(a.addedAt)));
  return result;
}

export function galleryItems(product) {
  return availableVariants(product).flatMap((variant) => variant.images.map((image, imageIndex) => ({ ...image, variant, imageIndex })));
}

export function validateOrder(product, values) {
  const errors = {};
  const required = { fullName: 'Enter your full name.', phone: 'Enter a contact phone number.', address: 'Enter your complete delivery address.', city: 'Enter your city.', country: 'Select your delivery country.' };
  for (const [key, message] of Object.entries(required)) {
    if (!String(values[key] || '').trim()) errors[key] = message;
  }
  const chosen = selectedSizes(product, values);
  for (const group of sizeGroups(product)) {
    if (!group.sizes.includes(chosen[group.key])) {
      const key = group.key === 'single' ? 'size' : `size_${group.key}`;
      errors[key] = group.key === 'single' ? 'Choose one of the available sizes.' : `Choose a ${group.label.toLowerCase()} size.`;
    }
  }
  if (!availableVariants(product).some((v) => v.id === values.color)) errors.color = 'Choose an available color.';
  const phone = String(values.phone || '');
  const digits = phone.replace(/\D/g, '');
  if (!errors.phone && (!/^[+\d\s().-]+$/.test(phone) || digits.length < 7 || digits.length > 15)) errors.phone = 'Enter a valid phone number, including your country code if needed.';
  if (!Number.isInteger(Number(values.quantity)) || Number(values.quantity) < 1 || Number(values.quantity) > product.maxQuantity) errors.quantity = `Choose a quantity from 1 to ${product.maxQuantity}.`;
  const limits = { fullName: 100, phone: 30, address: 500, city: 100, postalCode: 20, notes: 1000 };
  for (const [key, max] of Object.entries(limits)) if (String(values[key] || '').length > max) errors[key] = `Please keep this under ${max} characters.`;
  return errors;
}

export function buildOrderSummary(product, values) {
  const variant = findVariant(product, values.color);
  const totals = calculateTotals(product, values.quantity, values.country);
  const country = destinations.find((d) => d.code === values.country)?.name || values.country || 'To be confirmed';
  const clean = (value) => String(value || '').trim().replace(/\s+/g, ' ');
  const colorName = variant?.name || 'Not applicable';
  const chosen = selectedSizes(product, values);
  const perPiece = hasPieceSizes(product);
  const size = chosen.single ? sizeLabel(product, chosen.single) : 'Not selected';
  const pieceSizeLines = perPiece
    ? sizeGroups(product).map((g) => `${g.label} Size: ${chosen[g.key] ? sizeLabel(product, chosen[g.key]) : 'Not selected'}`)
    : [];
  const variantSuffix = perPiece
    ? sizeGroups(product).map((g) => `${g.label} ${chosen[g.key] || 'not selected'}`).join(' + ')
    : size;
  const shippingTime = product.delivery.estimate || 'To be confirmed on Instagram';
  const catalogUrl = site.siteUrl ? new URL(productPath(product, variant?.id), site.siteUrl).href : '';
  return [
    'BY RIDAH ORDER',
    '------------------------------',
    `Product: ${product.name}`,
    `Product Reference: ${product.referenceCode}`,
    `Product Link: ${product.referenceUrl}`,
    ...(catalogUrl ? [`Catalog Page: ${catalogUrl}`] : []),
    ...(product.pieces ? [
      '',
      `SET CONTENTS (${product.pieces.length} pieces, one outfit)`,
      ...product.pieces.map((piece, i) => {
        const chosenSize = piece.sizeKey ? chosen[piece.sizeKey] : '';
        const sizePart = piece.sizeKey ? ` | Size: ${chosenSize ? sizeLabel(product, chosenSize) : 'Not selected'}` : '';
        return `${i + 1}. ${piece.name}${sizePart} | Ref: ${piece.referenceCode} | ${piece.referenceUrl}`;
      }),
      'Both pieces are included for the single total below.',
    ] : []),
    '',
    'ORDER DETAILS',
    `Color: ${colorName}`,
    ...(perPiece ? pieceSizeLines : [`Size: ${size}`]),
    `Quantity: ${totals.quantity}`,
    `Selected Variant: ${colorName} / ${variantSuffix}`,
    ...(product.pieces ? [
      ...(perPiece ? ['Sizes Chosen Independently: yes (top and pants may differ)'] : ['Size Applies To: both pieces (top and pants)']),
      `Quantity Means: ${totals.quantity} complete ${totals.quantity === 1 ? 'set' : 'sets'} (${totals.quantity} top + ${totals.quantity} pants)`,
    ] : []),
    '',
    'CUSTOMER DETAILS',
    `Customer Name: ${clean(values.fullName)}`,
    `Phone: ${clean(values.phone)}`,
    `Address: ${clean(values.address)}`,
    `City: ${clean(values.city)}`,
    `Postal Code: ${clean(values.postalCode) || 'Not provided'}`,
    `Country: ${country}`,
    '',
    'PRICING',
    `Unit Price: ${formatMoney(totals.unitCents)} ${site.currency}`,
    `Product Subtotal: ${formatMoney(totals.productCents)} ${site.currency}`,
    `Shipping: ${formatMoney(totals.shippingCents)} ${site.currency}${totals.shippingCents === 0 ? ' (no additional charge)' : ''}`,
    `TOTAL: ${formatMoney(totals.totalCents, true)}`,
    'Shipping Included: Yes',
    `Shipping Time: ${shippingTime}`,
    `Delivery Estimate: ${shippingTime} — confirmed on Instagram for the delivery address`,
    '',
    `Order Notes: ${clean(values.notes) || 'None'}`,
    '',
    'Please confirm product, color, size, quantity, delivery address, and total before processing.',
    'This is an order request, not a confirmed or paid order.',
  ].join('\n');
}
