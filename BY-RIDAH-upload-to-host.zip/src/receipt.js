/**
 * BY RIDAH — order receipt image.
 *
 * Draws the completed order card to a PNG entirely in the browser using canvas.
 * Nothing is uploaded: the customer shares or saves the file themselves.
 *
 * Why an image at all: Instagram has no URL that accepts a prefilled message or
 * attachment, so the site cannot post into a chat. The best available path is to
 * hand a real image file to the OS share sheet (navigator.share), where the
 * customer picks Instagram. On desktop, where file sharing is unavailable, the
 * image is downloaded and the chat is opened so it can be attached by hand.
 */
import { site, destinations } from './data.js?v=34218b3741';
import {
  findVariant, calculateTotals, formatMoney, selectedSizes,
  sizeGroups, hasPieceSizes, sizeLabel,
} from './logic.js?v=34218b3741';

const W = 1080;
const PAD = 72;
const INNER = W - PAD * 2;
const SCALE = 2; // render at 2x so text stays crisp when Instagram compresses it

const INK = '#272922';
const MUTED = '#6f7166';
const LINE = '#e3e1d9';
const BG = '#faf9f6';
const PANEL = '#f2f1ea';

const SANS = '"DM Sans", system-ui, -apple-system, Segoe UI, sans-serif';
const SERIF = '"Instrument Serif", Georgia, serif';

const clean = (value) => String(value || '').trim().replace(/\s+/g, ' ');

/** Collect everything the receipt needs, independent of how it is drawn. */
export function buildReceiptData(product, values) {
  const variant = findVariant(product, values.color);
  const totals = calculateTotals(product, values.quantity, values.country);
  const chosen = selectedSizes(product, values);
  const perPiece = hasPieceSizes(product);
  const country = destinations.find((d) => d.code === values.country)?.name || values.country || '—';
  const sizeText = (key) => (chosen[key] ? sizeLabel(product, chosen[key]) : 'Not selected');

  return {
    product,
    variant,
    totals,
    image: variant?.images?.[0] || null,
    productName: product.name,
    referenceCode: product.referenceCode,
    referenceUrl: product.referenceUrl,
    colorName: variant?.name || 'Not applicable',
    sizeRows: perPiece
      ? sizeGroups(product).map((g) => [`${g.label} size`, sizeText(g.key)])
      : [['Size', sizeText('single')]],
    pieces: (product.pieces || []).map((piece) => ({
      name: piece.name,
      size: piece.sizeKey ? sizeText(piece.sizeKey) : '',
      referenceCode: piece.referenceCode,
    })),
    perPiece,
    quantity: totals.quantity,
    customer: [
      ['Name', clean(values.fullName)],
      ['Phone', clean(values.phone)],
      ['Address', clean(values.address)],
      ['City', clean(values.city)],
      ['Postal code', clean(values.postalCode) || 'Not provided'],
      ['Country', country],
    ],
    shippingTime: product.delivery.estimate || 'To be confirmed',
    notes: clean(values.notes) || 'None',
    prepared: new Date().toLocaleString(site.locale, {
      year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit',
    }),
  };
}

function wrapText(ctx, text, maxWidth) {
  const out = [];
  for (const paragraph of String(text).split('\n')) {
    let line = '';
    for (const word of paragraph.split(/\s+/).filter(Boolean)) {
      const candidate = line ? `${line} ${word}` : word;
      if (ctx.measureText(candidate).width <= maxWidth || !line) {
        // Break a single unbroken token (a long URL) rather than overflow.
        if (ctx.measureText(candidate).width > maxWidth && !line) {
          let chunk = '';
          for (const ch of word) {
            if (ctx.measureText(chunk + ch).width > maxWidth && chunk) { out.push(chunk); chunk = ch; }
            else chunk += ch;
          }
          line = chunk;
        } else line = candidate;
      } else { out.push(line); line = word; }
    }
    out.push(line);
  }
  return out.length ? out : [''];
}

function loadImage(src) {
  return new Promise((resolve) => {
    if (!src) return resolve(null);
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => resolve(null);
    img.src = src;
  });
}

/**
 * Lay out and optionally draw the card. Running it once with draw=false gives the
 * exact height, so the real canvas is allocated at the right size.
 */
function layout(ctx, data, photo, draw) {
  let y = PAD;
  const put = (text, x, yy, font, color, align = 'left') => {
    if (!draw) return;
    ctx.font = font; ctx.fillStyle = color; ctx.textAlign = align; ctx.textBaseline = 'alphabetic';
    ctx.fillText(text, x, yy);
  };
  const rule = (yy) => {
    if (!draw) return;
    ctx.strokeStyle = LINE; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(PAD, yy); ctx.lineTo(W - PAD, yy); ctx.stroke();
  };
  const section = (label) => {
    y += 30; rule(y); y += 46;
    put(label.toUpperCase(), PAD, y, `600 21px ${SANS}`, MUTED);
    y += 30;
  };
  // Label on the left, value on the right, wrapping within its column.
  const row = (label, value, opts = {}) => {
    const labelW = 250;
    const valueX = PAD + labelW + 24;
    const valueW = INNER - labelW - 24;
    const font = opts.strong ? `600 26px ${SANS}` : `400 25px ${SANS}`;
    if (draw) ctx.font = font;
    const lines = wrapText(ctx, value ?? '—', valueW);
    put(label, PAD, y + 25, `400 23px ${SANS}`, MUTED);
    lines.forEach((line, i) => put(line, valueX, y + 25 + i * 34, font, opts.color || INK));
    y += Math.max(38, lines.length * 34 + 8);
  };

  // Masthead
  put('BY RIDAH.', PAD, y + 44, `400 52px ${SERIF}`, INK);
  put('ORDER REQUEST', W - PAD, y + 40, `600 21px ${SANS}`, MUTED, 'right');
  y += 74;
  put(`Prepared ${data.prepared}`, PAD, y + 20, `400 21px ${SANS}`, MUTED);
  y += 44;

  // Product block with the actual photographed variant
  y += 26;
  const photoSize = 208;
  const textX = PAD + photoSize + 32;
  const textW = INNER - photoSize - 32;
  const blockTop = y;
  if (draw && photo) {
    ctx.save();
    ctx.beginPath();
    ctx.rect(PAD, blockTop, photoSize, photoSize);
    ctx.clip();
    ctx.fillStyle = PANEL; ctx.fillRect(PAD, blockTop, photoSize, photoSize);
    // Cover-fit the square source into the square slot.
    const ratio = Math.max(photoSize / photo.width, photoSize / photo.height);
    const dw = photo.width * ratio, dh = photo.height * ratio;
    ctx.drawImage(photo, PAD + (photoSize - dw) / 2, blockTop + (photoSize - dh) / 2, dw, dh);
    ctx.restore();
  }
  let ty = blockTop + 40;
  if (draw) ctx.font = `400 36px ${SERIF}`;
  for (const line of wrapText(ctx, data.productName, textW)) {
    put(line, textX, ty, `400 36px ${SERIF}`, INK); ty += 44;
  }
  ty += 6;
  put(`Ref ${data.referenceCode}`, textX, ty, `400 21px ${SANS}`, MUTED); ty += 34;
  put(`Color: ${data.colorName}`, textX, ty, `400 24px ${SANS}`, INK); ty += 32;
  const sizeSummary = data.sizeRows.map(([k, v]) => `${k}: ${v}`).join('   ·   ');
  if (draw) ctx.font = `400 24px ${SANS}`;
  for (const line of wrapText(ctx, sizeSummary, textW)) {
    put(line, textX, ty, `400 24px ${SANS}`, INK); ty += 32;
  }
  put(`Quantity: ${data.quantity}`, textX, ty, `400 24px ${SANS}`, INK); ty += 32;
  y = Math.max(blockTop + photoSize, ty) + 12;

  if (data.pieces.length) {
    section(`Set contents — ${data.pieces.length} pieces, one outfit`);
    data.pieces.forEach((piece, i) => {
      const label = `${i + 1}. ${piece.name}`;
      if (draw) ctx.font = `400 24px ${SANS}`;
      for (const line of wrapText(ctx, label, INNER)) { put(line, PAD, y + 24, `400 24px ${SANS}`, INK); y += 32; }
      put(`Size ${piece.size}   ·   Ref ${piece.referenceCode}`, PAD + 26, y + 22, `400 21px ${SANS}`, MUTED);
      y += 42;
    });
    put('Both pieces are included in the single total below.', PAD, y + 20, `400 21px ${SANS}`, MUTED);
    y += 34;
  }

  section('Delivery details');
  for (const [label, value] of data.customer) row(label, value);

  section('Pricing');
  row('Unit price', `${formatMoney(data.totals.unitCents)} ${site.currency}`);
  row('Subtotal', `${formatMoney(data.totals.productCents)} ${site.currency}`);
  row('Shipping', data.totals.shippingCents === 0 ? 'Included · $0.00' : `${formatMoney(data.totals.shippingCents)} ${site.currency}`);
  y += 10;
  if (draw) {
    ctx.fillStyle = PANEL;
    ctx.fillRect(PAD, y, INNER, 92);
  }
  put('TOTAL', PAD + 26, y + 58, `600 24px ${SANS}`, INK);
  put(formatMoney(data.totals.totalCents, true), W - PAD - 26, y + 60, `400 42px ${SERIF}`, INK, 'right');
  y += 92 + 30;
  row('Shipping time', data.shippingTime);

  section('Order notes');
  if (draw) ctx.font = `400 24px ${SANS}`;
  for (const line of wrapText(ctx, data.notes, INNER)) { put(line, PAD, y + 24, `400 24px ${SANS}`, INK); y += 34; }

  // Supplier reference is for the owner's manual processing, as in the text summary.
  y += 26; rule(y); y += 34;
  if (draw) ctx.font = `400 18px ${SANS}`;
  for (const line of wrapText(ctx, `Product link: ${data.referenceUrl}`, INNER)) {
    put(line, PAD, y + 18, `400 18px ${SANS}`, MUTED); y += 26;
  }
  y += 16;
  put('This is an order request, not a confirmed or paid order.', PAD, y + 20, `400 20px ${SANS}`, MUTED);
  y += 44;
  return y + PAD - 20;
}

/** Render the order card and resolve to a PNG Blob. */
export async function renderReceiptBlob(data) {
  // Canvas does not wait for webfonts; make sure the brand faces are ready.
  if (document.fonts?.load) {
    await Promise.all([
      document.fonts.load(`400 52px ${SERIF}`),
      document.fonts.load(`400 25px ${SANS}`),
      document.fonts.load(`600 25px ${SANS}`),
    ]).catch(() => {});
    await document.fonts.ready;
  }
  const photo = await loadImage(data.image?.src);
  const measure = document.createElement('canvas').getContext('2d');
  const height = Math.ceil(layout(measure, data, photo, false));

  const canvas = document.createElement('canvas');
  canvas.width = W * SCALE;
  canvas.height = height * SCALE;
  const ctx = canvas.getContext('2d');
  ctx.scale(SCALE, SCALE);
  ctx.fillStyle = BG;
  ctx.fillRect(0, 0, W, height);
  ctx.textAlign = 'left';
  layout(ctx, data, photo, true);

  return new Promise((resolve, reject) => {
    canvas.toBlob((blob) => (blob ? resolve(blob) : reject(new Error('Could not create the order image.'))), 'image/png');
  });
}

export function receiptFileName(data) {
  const slug = data.product.slug || 'order';
  const stamp = new Date().toISOString().slice(0, 10);
  return `BY-RIDAH-order-${slug}-${stamp}.png`;
}
