import { products as bundledProducts, site } from './data.js?v=34218b3741';
import { buildReceiptData, renderReceiptBlob, receiptFileName } from './receipt.js?v=34218b3741';
import { activeProducts, availableVariants, findVariant, filterProducts, galleryItems, productPath, calculateTotals, formatMoney, clampQuantity, validateOrder, buildOrderSummary, sizeLabel, sizeGroups, hasPieceSizes, sizeSummaryText, escapeHtml as e } from './logic.js?v=34218b3741';
import { productCard, sizeChartTable } from './views.js?v=34218b3741';
import { icon } from './icons.js?v=34218b3741';

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
let products = bundledProducts;
let liveProducts = activeProducts(products);
let toastTimer;

// The server renders the full catalog into the HTML. If a stale cached data.js is
// loaded, it must never be allowed to hide products that the server rendered.
function catalogLooksStale() {
  const known = new Set(products.map((p) => p.id));
  if ($$('[data-product-card]').some((el) => !known.has(el.dataset.productCard))) return true;
  const expected = Number(document.body.dataset.productCount || 0);
  return expected > 0 && liveProducts.length < expected;
}

async function refreshCatalogIfStale() {
  if (!catalogLooksStale()) return;
  try {
    const fresh = await import(`./data.js?refresh=${Date.now()}`);
    if (Array.isArray(fresh.products) && fresh.products.length > products.length) {
      products = fresh.products;
      liveProducts = activeProducts(products);
    }
  } catch { /* Keep the server-rendered catalog visible. */ }
}

function toast(message) {
  const el = $('#toast');
  $('span', el).textContent = message;
  el.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { el.hidden = true; }, 4200);
}

function openDialog(dialog) {
  if (!dialog.open) dialog.showModal();
  document.body.classList.add('dialog-open');
}

function initShared() {
  const menuButton = $('.menu-toggle');
  const mobileNav = $('#mobile-nav');
  menuButton?.addEventListener('click', () => {
    const open = menuButton.getAttribute('aria-expanded') !== 'true';
    menuButton.setAttribute('aria-expanded', String(open));
    menuButton.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
    menuButton.innerHTML = icon(open ? 'close' : 'menu');
    mobileNav.hidden = !open;
  });
  $$('#mobile-nav a').forEach((a) => a.addEventListener('click', () => {
    mobileNav.hidden = true;
    menuButton.setAttribute('aria-expanded', 'false');
    menuButton.setAttribute('aria-label', 'Open menu');
    menuButton.innerHTML = icon('menu');
  }));

  $$('dialog').forEach((dialog) => {
    dialog.addEventListener('keydown', (event) => {
      if (event.key === 'Escape') { event.preventDefault(); dialog.close(); }
    });
    dialog.addEventListener('close', () => {
      if (!document.querySelector('dialog[open]')) document.body.classList.remove('dialog-open');
    });
    dialog.addEventListener('click', (event) => {
      if (event.target !== dialog) return;
      const rect = dialog.getBoundingClientRect();
      if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) dialog.close();
    });
  });
  $$('[data-close-dialog]').forEach((button) => button.addEventListener('click', () => button.closest('dialog').close()));

  const searchDialog = $('#search-dialog');
  const searchInput = $('#global-search');
  function renderSearch() {
    const query = searchInput.value;
    const results = filterProducts(products, { query });
    $('#search-result-count').textContent = query.trim() ? `${results.length} ${results.length === 1 ? 'piece' : 'pieces'} found` : 'Explore the collection';
    $('#search-results').innerHTML = results.length ? results.map((p) => {
      const v = findVariant(p, p.cardVariantId);
      return `<a class="search-result" href="${e(productPath(p, v.id))}"><img src="${e(v.images[0].thumb)}" alt="${e(p.name)} in ${e(v.name)}" width="84" height="84"><div><h3>${e(p.name)}</h3><p>${e(p.categoryLabel)} · ${availableVariants(p).length === 1 ? (p.pieces ? '2-piece set' : '1 color') : `${availableVariants(p).length} colors`}</p><strong>${formatMoney(calculateTotals(p).totalCents)} <span class="muted">· Shipping included</span></strong></div>${icon('diagonal')}</a>`;
    }).join('') : `<div class="search-empty">No pieces match “${e(query)}”. Try “hoodie”, “shawl”, “set”, or a color.</div>`;
  }
  $$('[data-open-search]').forEach((button) => button.addEventListener('click', () => {
    renderSearch();
    openDialog(searchDialog);
    requestAnimationFrame(() => searchInput.focus());
  }));
  searchInput.addEventListener('input', renderSearch);
  searchInput.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') {
      const first = $('.search-result', $('#search-results'));
      if (first) window.location.assign(first.href);
    }
  });
  $$('[data-search-suggestion]').forEach((button) => button.addEventListener('click', () => {
    searchInput.value = button.dataset.searchSuggestion;
    renderSearch();
    searchInput.focus();
  }));
}

async function initHome() {
  await refreshCatalogIfStale();
  const params = new URLSearchParams(window.location.search);
  const state = { query: params.get('q') || '', category: params.get('category') || 'all', sort: 'featured' };
  const search = $('#catalog-search');
  const grid = $('#product-grid');
  search.value = state.query;
  // Preserve any server-rendered card this script does not know about.
  const knownIds = new Set(products.map((p) => p.id));
  const unknownCards = $$('[data-product-card]').filter((el) => !knownIds.has(el.dataset.productCard));
  const preservedCards = unknownCards.map((el) => el.outerHTML).join('');

  function applyFilters(updateUrl = true) {
    const results = filterProducts(products, state);
    const showAll = !state.query.trim() && state.category === 'all';
    const extra = showAll ? preservedCards : '';
    const total = results.length + (showAll ? unknownCards.length : 0);
    grid.innerHTML = results.map((p) => productCard(p)).join('') + extra;
    $('#result-count').textContent = `${total} ${total === 1 ? 'piece' : 'pieces'} ${state.query || state.category !== 'all' ? 'found' : 'in the collection'}`;
    $('#catalog-empty').hidden = total > 0;
    $('.collection-layout').hidden = total === 0;
    $$('[data-category]').forEach((button) => {
      const active = button.dataset.category === state.category;
      button.classList.toggle('is-active', active);
      button.setAttribute('aria-pressed', String(active));
    });
    if (updateUrl) {
      const url = new URL(window.location.href);
      state.query ? url.searchParams.set('q', state.query) : url.searchParams.delete('q');
      state.category !== 'all' ? url.searchParams.set('category', state.category) : url.searchParams.delete('category');
      window.history.replaceState({}, '', url);
    }
  }
  search.addEventListener('input', () => { state.query = search.value; applyFilters(); });
  $('#catalog-sort').addEventListener('change', (event) => { state.sort = event.target.value; applyFilters(false); });
  $$('[data-category]').forEach((button) => button.addEventListener('click', () => { state.category = button.dataset.category; applyFilters(); }));
  $('#clear-filters').addEventListener('click', () => {
    state.query = ''; state.category = 'all'; state.sort = 'featured';
    search.value = ''; $('#catalog-sort').value = 'featured'; applyFilters(); search.focus();
  });
  if (!$$('[data-category]').some((b) => b.dataset.category === state.category)) state.category = 'all';
  applyFilters(false);

  grid.addEventListener('click', (event) => {
    const button = event.target.closest('[data-card-color]');
    if (!button) return;
    const card = button.closest('[data-product-card]');
    const product = liveProducts.find((p) => p.id === card.dataset.productCard);
    const variant = findVariant(product, button.dataset.cardColor);
    const image = variant.images[0];
    const img = $('.product-card-image', card);
    img.src = image.src; img.srcset = `${image.small} 640w, ${image.src} 960w`; img.alt = image.alt;
    $('[data-card-color-name]', card).innerHTML = `${e(variant.name)} <span>· ${availableVariants(product).length} colors</span>`;
    $$('[data-card-link]', card).forEach((a) => { a.href = productPath(product, variant.id); });
    $$('[data-card-color]', card).forEach((b) => b.setAttribute('aria-pressed', String(b === button)));
  });

}

async function copyToClipboard(text) {
  try {
    if (navigator.clipboard?.writeText) { await navigator.clipboard.writeText(text); return true; }
  } catch { /* Fall back for restrictive browsers and embedded previews. */ }
  const area = document.createElement('textarea');
  area.value = text;
  area.setAttribute('readonly', '');
  area.style.cssText = 'position:fixed;left:-9999px;top:0;opacity:0;font-size:16px;';
  document.body.append(area);
  area.select();
  area.setSelectionRange(0, text.length);
  let ok = false;
  try { ok = document.execCommand('copy'); } catch { ok = false; }
  area.remove();
  return ok;
}

async function initProduct() {
  await refreshCatalogIfStale();
  const product = liveProducts.find((p) => p.slug === document.body.dataset.productSlug);
  if (!product) return;
  const items = galleryItems(product);
  const initialVariant = findVariant(product, new URLSearchParams(window.location.search).get('color'));
  const groups = sizeGroups(product);
  const perPiece = hasPieceSizes(product);
  const state = { galleryIndex: Math.max(0, items.findIndex((i) => i.variant.id === initialVariant.id)), size: '', sizes: Object.fromEntries(groups.map((g) => [g.key, ''])), quantity: 1, copied: false, copiedSummary: '', unit: 'in' };
  const form = $('#order-form');
  const quantityInput = $('#quantity');
  const copyButton = $('#copy-order');
  const copyStatus = $('#copy-status');
  const sendButton = $('#send-order');
  const downloadButton = $('#download-receipt');
  let receiptBlob = null;
  let receiptName = '';
  const lightbox = $('#lightbox');

  function readValues() {
    const values = Object.fromEntries(new FormData(form).entries());
    values.size = state.size;
    for (const group of groups) {
      if (group.key === 'single') values.size = state.sizes.single;
      else values[`size_${group.key}`] = state.sizes[group.key];
    }
    values.color = items[state.galleryIndex].variant.id;
    values.quantity = state.quantity;
    return values;
  }
  function currentSummary() {
    const values = readValues();
    return buildOrderSummary(product, values);
  }
  function updatePreview() { $('#order-preview').textContent = currentSummary(); }
  function invalidateCopy() {
    receiptBlob = null;
    downloadButton.hidden = true;
    if (state.copied) {
      state.copied = false;
      state.copiedSummary = '';
      copyButton.innerHTML = `${icon('copy')} <span>Copy as Text</span>`;
      copyStatus.textContent = 'Your details changed. Send or copy them again.';
      copyStatus.classList.remove('is-error');
    }
    updatePreview();
  }
  function clearFieldError(key) {
    const error = $(`#error-${key}`);
    if (error) { error.hidden = true; error.textContent = ''; }
    const input = $(`#${key}`);
    input?.removeAttribute('aria-invalid');
  }
  function updateTotals() {
    const country = $('#country').value;
    const totals = calculateTotals(product, state.quantity, country);
    state.quantity = totals.quantity;
    quantityInput.value = totals.quantity;
    $('#quantity-minus').disabled = totals.quantity <= 1;
    $('#quantity-plus').disabled = totals.quantity >= product.maxQuantity;
    $$('[data-total]').forEach((el) => { el.textContent = formatMoney(totals.totalCents); });
    $('#price-product').textContent = formatMoney(totals.productCents);
    $('#price-shipping').textContent = totals.shippingCents === 0 ? `Included · ${formatMoney(0)}` : formatMoney(totals.shippingCents);
    $('#price-quantity').textContent = `(${totals.quantity} ${totals.quantity === 1 ? 'piece' : 'pieces'})`;
    $('[data-summary-quantity]').textContent = totals.quantity;
    invalidateCopy();
  }
  function highlightSize() {
    $$('[data-chart-size]').forEach((row) => {
      const key = row.dataset.chartGroup || 'single';
      const chosen = state.sizes[key] || '';
      row.classList.toggle('is-selected', Boolean(chosen) && row.dataset.chartSize === chosen);
    });
  }
  function updateGallery({ updateUrl = true, scrollThumb = false } = {}) {
    const item = items[state.galleryIndex];
    const variant = item.variant;
    const img = $('#gallery-image');
    img.src = item.src; img.srcset = `${item.small} 640w, ${item.src} 960w`; img.alt = item.alt;
    $('#gallery-count').textContent = `${String(state.galleryIndex + 1).padStart(2, '0')} / ${String(items.length).padStart(2, '0')}`;
    $('#gallery-color-name').textContent = variant.name;
    $('#selected-color-name').textContent = variant.name;
    $('[data-summary-color]').textContent = variant.name;
    $('#order-color').value = variant.id;
    $('#gallery-open').setAttribute('aria-label', `Open larger image of ${product.name} in ${variant.name}${item.view ? `, ${item.view.toLowerCase()} view` : ''}`);
    $$('[data-color]').forEach((b) => { const active = b.dataset.color === variant.id; b.classList.toggle('is-active', active); b.setAttribute('aria-pressed', String(active)); });
    $$('[data-gallery-index]').forEach((b) => {
      const active = Number(b.dataset.galleryIndex) === state.galleryIndex;
      b.classList.toggle('is-active', active); b.setAttribute('aria-pressed', String(active));
      if (active && scrollThumb) {
        const rail = $('.gallery-thumbs');
        rail.scrollTo({ left: b.offsetLeft - rail.offsetLeft - rail.clientWidth / 2 + b.clientWidth / 2, behavior: 'smooth' });
      }
    });
    if (lightbox.open) {
      $('#lightbox-image').src = item.full || item.src;
      $('#lightbox-image').alt = item.alt;
      $('#lightbox-caption').textContent = `${variant.name}${item.view ? ` · ${item.view}` : ''} · ${state.galleryIndex + 1} / ${items.length}`;
    }
    if (updateUrl) {
      const url = new URL(window.location.href);
      url.searchParams.set('color', variant.id);
      window.history.replaceState({}, '', url);
    }
    clearFieldError('color');
    invalidateCopy();
    const next = items[(state.galleryIndex + 1) % items.length];
    const preload = new Image(); preload.src = next.src;
  }
  function selectVariant(id) {
    const index = items.findIndex((i) => i.variant.id === id);
    if (index < 0) return;
    state.galleryIndex = index;
    updateGallery({ scrollThumb: true });
  }
  function moveImage(direction) {
    state.galleryIndex = (state.galleryIndex + direction + items.length) % items.length;
    updateGallery({ scrollThumb: true });
  }
  $$('[data-color]').forEach((b) => b.addEventListener('click', () => selectVariant(b.dataset.color)));
  $$('[data-gallery-index]').forEach((b) => b.addEventListener('click', () => { state.galleryIndex = Number(b.dataset.galleryIndex); updateGallery({ scrollThumb: true }); }));
  $('#gallery-prev').addEventListener('click', () => moveImage(-1));
  $('#gallery-next').addEventListener('click', () => moveImage(1));
  $('#lightbox-prev').addEventListener('click', () => moveImage(-1));
  $('#lightbox-next').addEventListener('click', () => moveImage(1));
  $('#gallery-open').addEventListener('click', () => {
    const item = items[state.galleryIndex];
    $('#lightbox-image').src = item.full || item.src; $('#lightbox-image').alt = item.alt;
    $('#lightbox-caption').textContent = `${item.variant.name}${item.view ? ` · ${item.view}` : ''} · ${state.galleryIndex + 1} / ${items.length}`;
    openDialog(lightbox);
  });
  let touchStart = null;
  $('#gallery-stage').addEventListener('touchstart', (event) => {
    if (event.touches.length !== 1) { touchStart = null; return; }
    touchStart = { x: event.touches[0].clientX, y: event.touches[0].clientY };
  }, { passive: true });
  $('#gallery-stage').addEventListener('touchend', (event) => {
    if (!touchStart || !event.changedTouches.length) return;
    const dx = event.changedTouches[0].clientX - touchStart.x;
    const dy = event.changedTouches[0].clientY - touchStart.y;
    touchStart = null;
    if (Math.abs(dx) > 45 && Math.abs(dx) > Math.abs(dy) * 1.3) {
      moveImage(dx < 0 ? 1 : -1);
      $('#gallery-open').dataset.swiped = 'true';
      setTimeout(() => { delete $('#gallery-open').dataset.swiped; }, 400);
    }
  }, { passive: true });
  $('#gallery-open').addEventListener('click', (event) => {
    if (event.currentTarget.dataset.swiped) { event.preventDefault(); event.stopImmediatePropagation(); }
  }, { capture: true });
  $('#gallery-stage').addEventListener('keydown', (event) => {
    if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') { event.preventDefault(); moveImage(event.key === 'ArrowRight' ? 1 : -1); }
  });
  lightbox.addEventListener('keydown', (event) => {
    if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') { event.preventDefault(); moveImage(event.key === 'ArrowRight' ? 1 : -1); }
  });

  $$('[data-size]').forEach((button) => button.addEventListener('click', () => {
    const key = button.dataset.sizeGroup || 'single';
    const size = button.dataset.size;
    state.sizes[key] = size;
    if (key === 'single') state.size = size;
    // Only clear/set the buttons inside this piece's own selector.
    $$(`[data-size][data-size-group="${key}"]`).forEach((b) => {
      const active = b === button;
      b.classList.toggle('is-active', active);
      b.setAttribute('aria-pressed', String(active));
    });
    const nameEl = $(`#selected-size-name-${key}`);
    if (nameEl) nameEl.textContent = sizeLabel(product, size);
    const hidden = $(`#order-size-${key}`);
    if (hidden) hidden.value = size;
    $('[data-summary-size]').textContent = sizeSummaryText(product, readValues());
    clearFieldError(key === 'single' ? 'size' : `size_${key}`);
    highlightSize();
    invalidateCopy();
  }));
  $$('[data-open-size]').forEach((button) => button.addEventListener('click', () => {
    highlightSize();
    openDialog($('#size-dialog'));
    const key = button.dataset.openSize;
    const title = key && perPiece ? $(`[data-chart-title="${key}"]`) : null;
    if (title) requestAnimationFrame(() => title.scrollIntoView({ block: 'start', behavior: 'smooth' }));
  }));
  $$('[data-unit]').forEach((button) => button.addEventListener('click', () => {
    state.unit = button.dataset.unit;
    $('#size-chart-content').innerHTML = sizeChartTable(product, state.unit);
    $$('[data-unit]').forEach((b) => { const active = b === button; b.classList.toggle('is-active', active); b.setAttribute('aria-pressed', String(active)); });
    highlightSize();
  }));

  $('#quantity-minus').addEventListener('click', () => { state.quantity = clampQuantity(state.quantity - 1, product.maxQuantity); updateTotals(); });
  $('#quantity-plus').addEventListener('click', () => { state.quantity = clampQuantity(state.quantity + 1, product.maxQuantity); updateTotals(); });
  quantityInput.addEventListener('input', () => {
    const raw = Number(quantityInput.value);
    if (Number.isFinite(raw) && raw >= 1 && raw <= product.maxQuantity) { state.quantity = clampQuantity(raw, product.maxQuantity); updateTotals(); }
  });
  quantityInput.addEventListener('change', () => { state.quantity = clampQuantity(quantityInput.value, product.maxQuantity); clearFieldError('quantity'); updateTotals(); });
  $('#country').addEventListener('change', () => { clearFieldError('country'); updateTotals(); });
  form.addEventListener('input', (event) => {
    if (event.target.name) clearFieldError(event.target.name);
    invalidateCopy();
  });
  form.addEventListener('change', (event) => { if (event.target.name) clearFieldError(event.target.name); invalidateCopy(); });
  $('.order-preview-details').addEventListener('toggle', updatePreview);

  function showErrors(errors) {
    $$('.field-error').forEach((el) => { el.hidden = true; el.textContent = ''; });
    $$('[aria-invalid]', form).forEach((el) => el.removeAttribute('aria-invalid'));
    $$('[aria-invalid]', $('#product-options')).forEach((el) => el.removeAttribute('aria-invalid'));
    const keys = Object.keys(errors);
    const summary = $('#form-errors');
    summary.hidden = keys.length === 0;
    if (!keys.length) return;
    summary.textContent = 'Almost there. Please complete the highlighted fields before copying or sending your order.';
    keys.forEach((key) => {
      const error = $(`#error-${key}`);
      if (error) { error.textContent = errors[key]; error.hidden = false; }
      const input = $(`#${key}`);
      if (input) input.setAttribute('aria-invalid', 'true');
    });
    const first = keys[0];
    const sizeMatch = /^size_(.+)$/.exec(first);
    const target = first === 'size' ? $('[data-size-group="single"]') || $('[data-size]')
      : sizeMatch ? $(`[data-size-group="${sizeMatch[1]}"]`)
      : first === 'color' ? $('[data-color]') : $(`#${first}`);
    if (target) { target.focus({ preventScroll: true }); target.scrollIntoView({ behavior: 'smooth', block: 'center' }); }
  }
  function validate() {
    const values = readValues();
    const errors = validateOrder(product, values);
    showErrors(errors);
    return Object.keys(errors).length === 0;
  }
  function markCopied(summary) {
    state.copied = true;
    state.copiedSummary = summary;
    copyButton.innerHTML = `${icon('check')} <span>Text Copied</span>`;
    copyStatus.textContent = 'Order details copied as text. You can paste this into Instagram instead of the image.';
    copyStatus.classList.remove('is-error');
    toast('Order text copied!');
  }
  // Build the PNG once per change, then reuse it for both share and download.
  async function ensureReceipt() {
    if (receiptBlob) return receiptBlob;
    const data = buildReceiptData(product, readValues());
    receiptBlob = await renderReceiptBlob(data);
    receiptName = receiptFileName(data);
    return receiptBlob;
  }
  function saveReceipt(blob) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = receiptName || 'BY-RIDAH-order.png';
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 10000);
  }
  downloadButton.addEventListener('click', async () => {
    if (!validate()) return;
    try {
      saveReceipt(await ensureReceipt());
      copyStatus.textContent = 'Order image saved. Attach it in your Instagram chat with us.';
      copyStatus.classList.remove('is-error');
    } catch {
      copyStatus.textContent = 'Could not create the image. Use “Copy as Text” instead.';
      copyStatus.classList.add('is-error');
    }
  });

  // Primary action: turn the completed card into an image and hand it to Instagram.
  // Instagram accepts no prefilled attachment by URL, so we use the OS share sheet
  // where available and otherwise save the image and open the chat to attach it.
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (!validate()) return;
    const label = sendButton.querySelector('span');
    const original = label.textContent;
    sendButton.disabled = true;
    label.textContent = 'Preparing image…';
    let blob;
    try { blob = await ensureReceipt(); }
    catch {
      sendButton.disabled = false; label.textContent = original;
      copyStatus.textContent = 'Could not create the order image. Use “Copy as Text” and paste it into Instagram.';
      copyStatus.classList.add('is-error');
      return;
    }
    sendButton.disabled = false; label.textContent = original;
    downloadButton.hidden = false;
    const file = new File([blob], receiptName, { type: 'image/png' });
    if (navigator.canShare?.({ files: [file] })) {
      try {
        await navigator.share({ files: [file], title: 'BY RIDAH order', text: currentSummary() });
        copyStatus.textContent = 'Order image shared. We’ll confirm your order personally on Instagram.';
        copyStatus.classList.remove('is-error');
        toast('Order image shared');
        return;
      } catch (error) {
        if (error?.name === 'AbortError') {
          copyStatus.textContent = 'Sharing cancelled. Tap “Save order image” to send it manually.';
          copyStatus.classList.remove('is-error');
          return;
        }
      }
    }
    // Desktop, or the share sheet refused: save the image and open the chat.
    saveReceipt(blob);
    window.open(site.instagramUrl, '_blank', 'noopener');
    copyStatus.textContent = 'Order image saved to your device. Instagram is opening — attach the image in the chat and send.';
    copyStatus.classList.remove('is-error');
    toast('Order image saved');
  });

  // Secondary action: plain-text copy, with the existing manual-copy fallback.
  copyButton.addEventListener('click', async () => {
    if (!validate()) return;
    const summary = currentSummary();
    copyButton.disabled = true;
    const ok = await copyToClipboard(summary);
    copyButton.disabled = false;
    if (ok) markCopied(summary);
    else {
      $('#manual-copy-text').value = summary;
      openDialog($('#manual-copy-dialog'));
      requestAnimationFrame(() => { $('#manual-copy-text').focus(); $('#manual-copy-text').select(); });
      copyStatus.textContent = 'Automatic copying is unavailable. Copy the text in the window, then send it on Instagram.';
    }
  });
  $('#select-copy-text').addEventListener('click', () => { $('#manual-copy-text').focus(); $('#manual-copy-text').select(); $('#manual-copy-text').setSelectionRange(0, $('#manual-copy-text').value.length); });
  $('#confirm-manual-copy').addEventListener('click', () => {
    markCopied($('#manual-copy-text').value);
    $('#manual-copy-dialog').close();
    sendButton.focus();
  });

  const mobileBar = $('#mobile-order-bar');
  const orderSection = $('#want-to-order');
  let scrollScheduled = false;
  function updateMobileBar() {
    mobileBar.hidden = orderSection.getBoundingClientRect().top < window.innerHeight * 0.72;
    scrollScheduled = false;
  }
  window.addEventListener('scroll', () => {
    if (!scrollScheduled) { scrollScheduled = true; requestAnimationFrame(updateMobileBar); }
  }, { passive: true });
  window.addEventListener('resize', updateMobileBar, { passive: true });
  updateGallery({ updateUrl: false });
  updateTotals();
  updateMobileBar();
}

initShared();
if (document.body.dataset.page === 'home') initHome();
if (document.body.dataset.page === 'product') initProduct();
