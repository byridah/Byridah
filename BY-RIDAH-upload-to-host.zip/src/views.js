import { site, categories, destinations } from './data.js?v=34218b3741';
import { escapeHtml as e, activeProducts, availableVariants, findVariant, productPath, unitPriceCents, calculateTotals, formatMoney, galleryItems, sizeLabel, sizeGroups, hasPieceSizes } from './logic.js?v=34218b3741';
import { icon } from './icons.js?v=34218b3741';

export function imageMarkup(image, className = '', { eager = false, sizes = '(min-width: 900px) 50vw, 100vw', id = '' } = {}) {
  return `<img ${id ? `id="${e(id)}"` : ''} class="${e(className)}" src="${e(image.src)}" srcset="${e(image.small)} 640w, ${e(image.src)} 960w" sizes="${e(sizes)}" width="${image.width || 960}" height="${image.height || 960}" alt="${e(image.alt)}" loading="${eager ? 'eager' : 'lazy'}" decoding="async" ${eager ? 'fetchpriority="high"' : ''}>`;
}

export function header(page = 'home') {
  return `<a class="skip-link" href="#main">Skip to content</a>
  <aside class="announcement" aria-label="Store announcement"><span>${e(site.tagline)}</span></aside>
  <header class="site-header">
    <div class="header-inner">
      <a class="wordmark" href="/" aria-label="BY RIDAH home">BY RIDAH<span class="wordmark-dot" aria-hidden="true">.</span></a>
      <nav class="desktop-nav" aria-label="Main navigation">
        <a href="/" ${page === 'home' ? 'aria-current="page"' : ''}>Home</a>
        <a href="/#collection">Products</a>
        <a href="/#how-it-works">How to order</a>
      </nav>
      <div class="header-actions">
        <button class="header-search" type="button" data-open-search aria-label="Search products">${icon('search')}<span>Search</span></button>
        <button class="menu-toggle" type="button" aria-label="Open menu" aria-expanded="false" aria-controls="mobile-nav">${icon('menu')}</button>
      </div>
    </div>
    <nav id="mobile-nav" class="mobile-nav" aria-label="Mobile navigation" hidden>
      <a href="/">Home ${icon('home')}</a><a href="/#collection">Products ${icon('arrow')}</a><a href="/#how-it-works">How to order ${icon('arrow')}</a>
    </nav>
  </header>`;
}

export function footer() {
  return `<footer class="site-footer" id="contact">
    <div class="footer-main wrap">
      <div class="footer-brand"><a class="wordmark" href="/">BY RIDAH<span class="wordmark-dot" aria-hidden="true">.</span></a><p>Considered pieces for everyday life.<br>Chosen by you. Ordered personally.</p></div>
      <div class="footer-links"><h2 class="eyebrow">Explore</h2><a href="/">Home</a><a href="/#collection">Products</a><a href="/#how-it-works">How ordering works</a><a href="#contact">Contact</a></div>
      <div class="footer-contact"><h2 class="eyebrow">A conversation, not a checkout</h2><p>${e(site.support)}</p></div>
    </div>
    <div class="footer-bottom wrap"><span>© ${new Date().getFullYear()} BY RIDAH</span><span>Orders are processed manually through Instagram.</span><a href="#main">Back to top ${icon('arrow')}</a></div>
  </footer>`;
}

export function productCard(product, variantId = product.cardVariantId) {
  const variant = findVariant(product, variantId);
  const image = variant.images[0];
  const price = calculateTotals(product, 1).totalCents;
  return `<article class="product-card" data-product-card="${e(product.id)}">
    <div class="product-card-media">
      <a href="${e(productPath(product, variant.id))}" data-card-link aria-label="View ${e(product.name)} in ${e(variant.name)}${product.badge ? `. ${e(product.badge)}` : ''}">
        ${imageMarkup(image, 'product-card-image', { eager: true, sizes: '(min-width: 1000px) 48vw, (min-width: 640px) 80vw, 100vw' })}
        ${product.badge ? `<span class="product-badge">${e(product.badge)}</span>` : ''}
        <span class="card-view" aria-hidden="true">View piece ${icon('diagonal')}</span>
      </a>
    </div>
    <div class="product-card-info">
      <div><p class="product-category">${e(product.categoryLabel)}</p><h3><a href="${e(productPath(product, variant.id))}" data-card-link>${e(product.name)}</a></h3><p class="card-color-name" data-card-color-name>${e(variant.name)} <span>· ${availableVariants(product).length === 1 ? (product.pieces ? '2-piece set' : '1 color') : `${availableVariants(product).length} colors`}</span></p></div>
      <div class="card-price"><span>${formatMoney(price)}</span><small>Shipping included</small></div>
    </div>
    <div class="card-swatches" role="group" aria-label="Preview available colors">${availableVariants(product).map((v) => `<button type="button" class="swatch-hit" data-card-color="${e(v.id)}" aria-label="Preview ${e(v.name)}" aria-pressed="${v.id === variant.id}" title="${e(v.name)}"><span class="swatch" style="--swatch:${e(v.hex)}"></span></button>`).join('')}</div>
  </article>`;
}

export function home(products) {
  const live = activeProducts(products);
  return `<main id="main">
    <section class="collection-intro wrap" aria-labelledby="intro-title">
      <p class="eyebrow"><span class="tiny-line" aria-hidden="true"></span> The everyday edit</p>
      <h1 id="intro-title">Everyday pieces.<br><em>Chosen by you.</em></h1>
      <p class="collection-intro-note">Browse the full collection below. Choose your size and color, then send your order to us as a single image — no cart, no checkout, no online payment.</p>
    </section>

    <div class="promise-strip wrap" aria-label="The BY RIDAH way"><span>${icon('truck')} Shipping included in your total</span><span>${icon('instagram')} Ordered through Instagram</span><span>${icon('shield')} No online payment. No checkout.</span></div>

    <section class="collection wrap" id="collection" aria-labelledby="collection-title">
      <div class="section-heading"><div><p class="eyebrow">The collection</p><h2 id="collection-title">Fewer pieces. <em>More possibility.</em></h2></div><p class="section-aside">An edit of everyday favorites.<br>Take your time. Find your piece.</p></div>
      <div class="catalog-toolbar">
        <div class="category-filters" role="group" aria-label="Filter by category"><button type="button" class="filter-chip is-active" data-category="all" aria-pressed="true">All pieces</button>${categories.map((c) => `<button type="button" class="filter-chip" data-category="${e(c.id)}" aria-pressed="false">${e(c.label)}</button>`).join('')}</div>
        <div class="catalog-tools"><label class="catalog-search">${icon('search')}<span class="sr-only">Search the collection</span><input id="catalog-search" type="search" placeholder="Search the collection" autocomplete="off"></label><label class="sort-label"><span class="sr-only">Sort products</span><select id="catalog-sort"><option value="featured">Featured</option><option value="newest">Newest</option><option value="price-asc">Price: low to high</option><option value="price-desc">Price: high to low</option><option value="name">Name: A–Z</option></select>${icon('down')}</label></div>
      </div>
      <p class="result-count" id="result-count" role="status">${live.length} ${live.length === 1 ? 'piece' : 'pieces'} in the collection</p>
      <div class="collection-layout ${live.length === 1 ? 'single-piece' : ''}">
        <div class="product-grid" id="product-grid">${live.map((p) => productCard(p)).join('')}</div>
      </div>
      <div class="empty-state" id="catalog-empty" hidden>${icon('search')}<h3>No pieces found</h3><p>Try a different word or explore the full collection.</p><button type="button" class="button button-outline" id="clear-filters">Clear search & filters</button></div>
    </section>

    <section class="how-section" id="how-it-works" aria-labelledby="how-title"><div class="wrap how-layout">
      <div class="how-intro"><p class="eyebrow">How ordering works</p><h2 id="how-title">From our collection<br>to <em>your conversation.</em></h2><p>No cart. No checkout. Just a simple, personal way to order your next everyday favorite.</p><div class="how-note">${icon('instagram')}<span>Every order is confirmed personally.<br>Your message is the beginning, not a payment.</span></div></div>
      <ol class="how-steps">${[
        ['Choose your product', 'Explore the collection and open a piece you love.'],
        ['Make it yours', 'Select your color, size, and quantity.'],
        ['Add delivery details', 'Enter only the details needed for your order.'],
        ['Check your total', 'See one clear price, with shipping included.'],
        ['Copy your order', 'One tap puts your order summary on your clipboard.'],
        ['Send the image', 'Share your order image to Instagram, or save it and attach it in our chat.'],
        ['We take it from there', 'We confirm your order personally before processing it.'],
      ].map(([title, text], i) => `<li><span class="step-number">${String(i + 1).padStart(2, '0')}</span><div><h3>${title}</h3><p>${text}</p></div></li>`).join('')}</ol>
    </div></section>
  </main>`;
}

function oneChart(product, chart, unit, label = '', key = 'single') {
  const unitName = unit === 'in' ? 'inches' : 'centimeters';
  const group = sizeGroups(product).find((g) => g.key === key);
  const allowed = group ? group.sizes : product.sizes;
  const rows = chart[unit].filter((row) => allowed.includes(row[0]));
  const caption = `${product.name}${label ? ` — ${label}` : ''} size chart in ${unitName}`;
  return `${label ? `<h3 class="size-chart-part-title" data-chart-title="${e(key)}">${e(label)}</h3>` : ''}<div class="size-table-scroll" tabindex="0" role="region" aria-label="${e(caption)}; scroll horizontally if needed"><table class="size-table"><caption class="sr-only">${e(caption)}</caption><thead><tr>${chart.columns.map((col, i) => `<th scope="col">${e(col)}${i ? `<span> (${unit})</span>` : ''}</th>`).join('')}</tr></thead><tbody>${rows.map((row) => `<tr data-chart-size="${e(row[0])}" data-chart-group="${e(key)}">${row.map((cell, i) => i === 0 ? `<th scope="row">${e(cell)}</th>` : `<td>${e(cell)}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
}

export function sizeChartTable(product, unit = 'in') {
  // Sets carry one chart per piece; single garments carry one chart.
  if (product.sizeChart.parts) return product.sizeChart.parts.map((part) => oneChart(product, part, unit, part.label, part.key || 'single')).join('');
  return oneChart(product, product.sizeChart, unit);
}

function field(name, label, { type = 'text', autocomplete = '', placeholder = '', required = true, maxlength = 100, inputmode = '', half = false } = {}) {
  return `<div class="form-field ${half ? 'half' : ''}" data-field="${name}"><label for="${name}">${label}${required ? '<span aria-hidden="true"> *</span>' : '<span class="optional"> (optional)</span>'}</label><input id="${name}" name="${name}" type="${type}" ${autocomplete ? `autocomplete="${autocomplete}"` : ''} ${inputmode ? `inputmode="${inputmode}"` : ''} placeholder="${e(placeholder)}" maxlength="${maxlength}" ${required ? 'required' : ''} aria-describedby="error-${name}"><p class="field-error" id="error-${name}" hidden></p></div>`;
}

export function orderForm(product, variant) {
  return `<section class="order-section wrap" id="want-to-order" aria-labelledby="order-title">
    <div class="order-intro"><p class="eyebrow">A personal way to order</p><h2 id="order-title">Want to <em>Order?</em></h2><p>Choose your options and fill in your delivery details. We’ll turn the whole card into a single image you can send us on Instagram.</p>
      <ol class="order-mini-steps"><li><span>1</span><div><strong>Fill in your details</strong><p>Check your selection and delivery information.</p></div></li><li><span>2</span><div><strong>Tap “Send Order to Us”</strong><p>We turn your details into one order image.</p></div></li><li><span>3</span><div><strong>Share it to Instagram</strong><p>Pick Instagram and send. We’ll confirm personally.</p></div></li></ol>
      <div class="privacy-note">${icon('shield')}<p>Your details stay in this page. The order image is created on your own device and is never uploaded here. This website does not submit your personal information or place an order.</p></div>
    </div>
    <form id="order-form" class="order-form" novalidate>
      ${sizeGroups(product).map((group) => `<input type="hidden" name="${e(group.key === 'single' ? 'size' : `size_${group.key}`)}" id="order-size-${e(group.key)}" value="">`).join('')}<input type="hidden" name="color" id="order-color" value="${e(variant.id)}">
      <div class="selection-summary"><div><span class="eyebrow">Your selection</span><strong data-summary-product>${e(product.name)}</strong><span class="selection-variant"><span data-summary-color>${e(variant.name)}</span> <span aria-hidden="true">·</span> <span data-summary-size>${e(hasPieceSizes(product) ? sizeGroups(product).map((g) => `${g.label} —`).join(' · ') : 'Size not selected')}</span> <span aria-hidden="true">·</span> Qty <span data-summary-quantity>1</span></span><span class="selection-shipping">${icon('truck')} Shipping time: <span data-shipping-time>${e(product.delivery.estimate || 'Confirmed on Instagram')}</span></span></div><a href="#product-options" class="text-link">Change ${icon('up')}</a></div>
      <div class="form-error-summary" id="form-errors" role="alert" hidden></div>
      <div class="form-grid">
        ${field('fullName', 'Full name', { autocomplete: 'name', placeholder: 'Your full name' })}
        ${field('phone', 'Phone number', { type: 'tel', autocomplete: 'tel', inputmode: 'tel', placeholder: 'Include country code if needed', maxlength: 30 })}
        <div class="form-field full" data-field="address"><label for="address">Complete delivery address<span aria-hidden="true"> *</span></label><textarea id="address" name="address" rows="3" autocomplete="street-address" placeholder="House / flat, street, area, and any useful delivery landmark" maxlength="500" required aria-describedby="error-address"></textarea><p class="field-error" id="error-address" hidden></p></div>
        ${field('city', 'City', { autocomplete: 'address-level2', placeholder: 'Your city', half: true })}
        ${field('postalCode', 'Postal code', { autocomplete: 'postal-code', inputmode: 'text', placeholder: 'If applicable', required: false, maxlength: 20, half: true })}
        <div class="form-field full" data-field="country"><label for="country">Delivery country<span aria-hidden="true"> *</span></label><select id="country" name="country" autocomplete="country" required aria-describedby="error-country"><option value="">Select your country</option>${destinations.map((d) => `<option value="${e(d.code)}">${e(d.name)}</option>`).join('')}</select><p class="field-error" id="error-country" hidden></p></div>
        <div class="form-field full" data-field="notes"><label for="notes">Order notes<span class="optional"> (optional)</span></label><textarea id="notes" name="notes" rows="2" placeholder="Anything you’d like us to know?" maxlength="1000" aria-describedby="error-notes"></textarea><p class="field-error" id="error-notes" hidden></p></div>
      </div>
      <div class="form-total"><div><span>Your total</span><small>Shipping included · <span data-shipping-time>${e(product.delivery.estimate || 'confirmed on Instagram')}</span></small></div><strong data-total>${formatMoney(unitPriceCents(product))}</strong></div>
      <details class="order-preview-details"><summary>Preview order details ${icon('down')}</summary><pre id="order-preview"></pre></details>
      <div class="order-actions"><button class="button button-dark" id="send-order" type="submit">${icon('instagram')} <span>Send Order to Us</span></button><button class="button button-outline" id="copy-order" type="button">${icon('copy')} <span>Copy as Text</span></button></div>
      <button class="receipt-download" id="download-receipt" type="button" hidden>${icon('download')} Save order image</button>
      <p class="copy-status" id="copy-status" role="status" aria-live="polite"></p>
      <p class="order-disclaimer">${e(site.orderConfirmation)}</p>
    </form>
  </section>`;
}

export function productPage(product, initialVariantId) {
  const variant = findVariant(product, initialVariantId);
  const items = galleryItems(product);
  const initialIndex = Math.max(0, items.findIndex((i) => i.variant.id === variant.id));
  const initialImage = items[initialIndex];
  const totals = calculateTotals(product);
  return `<main id="main" class="product-page">
    <nav class="breadcrumb wrap" aria-label="Breadcrumb"><a href="/">Home</a>${icon('chevron')}<a href="/?category=${e(product.categories[0] || 'all')}#collection">${e(categories.find((c) => c.id === product.categories[0])?.label || 'Collection')}</a>${icon('chevron')}<span aria-current="page">${e(product.name)}</span></nav>
    <div class="product-layout wrap">
      <section class="gallery" aria-label="Product image gallery">
        <div class="gallery-stage" id="gallery-stage">
          <button type="button" class="gallery-main-button" id="gallery-open" aria-label="Open larger product image">${imageMarkup(initialImage, 'gallery-image', { eager: true, sizes: '(min-width: 1000px) 55vw, 100vw', id: 'gallery-image' })}<span class="gallery-expand">${icon('expand')}</span></button>
          <button type="button" class="gallery-arrow prev" id="gallery-prev" aria-label="Previous product image"${items.length > 1 ? '' : ' hidden'}>${icon('chevron')}</button><button type="button" class="gallery-arrow next" id="gallery-next" aria-label="Next product image"${items.length > 1 ? '' : ' hidden'}>${icon('chevron')}</button>
          <span class="gallery-count" id="gallery-count"${items.length > 1 ? '' : ' hidden'}>${String(initialIndex + 1).padStart(2, '0')} / ${String(items.length).padStart(2, '0')}</span>
        </div>
        <div class="gallery-thumbs" aria-label="Choose a product image to view"${items.length > 1 ? '' : ' hidden'}>${items.map((item, index) => `<button type="button" class="gallery-thumb ${index === initialIndex ? 'is-active' : ''}" data-gallery-index="${index}" aria-label="View ${e(item.variant.name)}${item.view ? ` ${e(item.view.toLowerCase())}` : ''}" aria-pressed="${index === initialIndex}" title="${e(item.variant.name)}${item.view ? ` · ${e(item.view)}` : ''}"><img src="${e(item.thumb)}" width="160" height="160" alt="" loading="lazy" decoding="async"></button>`).join('')}</div>
        <p class="gallery-hint"><span>${e(product.galleryHint || 'Swipe to explore the shades')}</span><span>Photographed in <span id="gallery-color-name">${e(variant.name)}</span></span></p>
      </section>
      <section class="product-info" id="product-options" aria-labelledby="product-title">
        <p class="eyebrow">${e(product.subtitle)}</p><h1 id="product-title">${e(product.name)}</h1>
        <div class="product-price-row"><span class="product-price">${formatMoney(totals.unitCents)}</span><span class="shipping-pill">${icon('check')} Shipping included</span></div>
        <p class="product-short-description">${e(product.description)}</p>
        ${product.pieces ? `<div class="set-contents"><p class="eyebrow">What’s included</p><ul>${product.pieces.map((piece) => `<li>${icon('check')}<span><strong>${e(piece.name)}</strong><small>${e(piece.material)}</small></span></li>`).join('')}</ul><p class="set-contents-note">Both pieces for one price. Choose a size for each piece.</p></div>` : ''}
        <div class="option-block color-block"><div class="option-heading"><h2>Color <span id="selected-color-name">${e(variant.name)}</span></h2><span>${availableVariants(product).length === 1 ? '1 colorway' : `${availableVariants(product).length} shades`}</span></div><div class="color-options" role="group" aria-label="Available colors">${availableVariants(product).map((v) => `<button type="button" class="color-option ${v.id === variant.id ? 'is-active' : ''}" data-color="${e(v.id)}" aria-pressed="${v.id === variant.id}"><span class="swatch" style="--swatch:${e(v.hex)}"></span><span>${e(v.name)}</span>${icon('check')}</button>`).join('')}</div><p class="field-error" id="error-color" hidden></p></div>
        ${sizeGroups(product).map((group) => {
          const multi = hasPieceSizes(product);
          const field = multi ? `size_${group.key}` : 'size';
          const heading = multi ? `${group.label} size` : 'Size';
          return `<div class="option-block size-block" data-size-block="${e(group.key)}"><div class="option-heading"><h2>${e(heading)} <span id="selected-size-name-${e(group.key)}">Select ${multi ? 'a ' : ''}size</span></h2><button type="button" class="text-link size-guide-trigger" data-open-size="${e(group.key)}">${icon('ruler')} Size chart</button></div><div class="size-options" role="group" aria-label="${e(multi ? `Available ${group.label.toLowerCase()} sizes` : 'Available sizes')}">${group.sizes.map((size) => `<button type="button" class="size-option" data-size="${e(size)}" data-size-group="${e(group.key)}" aria-pressed="false" aria-label="${e(multi ? `${group.label} size ` : 'Size ')}${e(sizeLabel(product, size))}${size === '2XL' ? ' (XXL)' : ''}">${e(group.sizes.length === 1 && size === 'M' ? 'One Size' : size)}</button>`).join('')}</div><p class="field-error" id="error-${e(field)}" hidden></p>${multi ? '' : `<p class="option-help">${e(product.sizeHelp || 'Check the measurements before choosing.')}</p>`}</div>`;
        }).join('')}
        ${hasPieceSizes(product) ? `<p class="option-help piece-size-help">${e(product.sizeHelp || 'Choose a size for each piece.')}</p>` : ''}
        <div class="quantity-row"><div><h2>Quantity</h2><p class="field-error" id="error-quantity" hidden></p></div><div class="quantity-control"><button type="button" id="quantity-minus" aria-label="Decrease quantity" disabled>${icon('minus')}</button><label class="sr-only" for="quantity">Quantity</label><input id="quantity" name="quantity" form="order-form" type="number" min="1" max="${product.maxQuantity}" value="1" inputmode="numeric" aria-describedby="error-quantity"><button type="button" id="quantity-plus" aria-label="Increase quantity">${icon('plus')}</button></div></div>
        <div class="price-breakdown" aria-label="Price including shipping"><div><span>Product price <small id="price-quantity">(1 piece)</small></span><span id="price-product">${formatMoney(totals.productCents)}</span></div><div><span>Shipping</span><span id="price-shipping">${totals.shippingCents === 0 ? 'Included · $0.00' : formatMoney(totals.shippingCents)}</span></div><div class="total-line"><span>TOTAL</span><strong id="price-total" data-total>${formatMoney(totals.totalCents)}</strong></div><p>${icon('check')} One clear total. Shipping included. No online payment.</p><p class="shipping-time-note">${icon('truck')} Shipping time: <span data-shipping-time>${e(product.delivery.estimate || 'confirmed on Instagram')}</span></p></div>
        <a class="button button-dark prepare-order" href="#want-to-order">Prepare my order ${icon('arrow')}</a>
        <div class="product-assurances"><span>${icon('instagram')} Personally confirmed</span><span>${icon('shield')} No payment on this site</span></div>
        <div class="product-accordions">
          <details open><summary>Fabric & fit ${icon('plus')}</summary><dl class="spec-list"><div><dt>Fabric</dt><dd>${e(product.fabric)}</dd></div><div><dt>Material</dt><dd>${e(product.material)}</dd></div><div><dt>Fabric weight</dt><dd>${e(product.fabricWeight)}</dd></div><div><dt>Fit</dt><dd>${e(product.fit)}</dd></div><div><dt>Type</dt><dd>${e(product.productType)}</dd></div></dl><ul class="feature-list">${product.features.map((f) => `<li>${e(f)}</li>`).join('')}</ul></details>
          <details><summary>Care instructions ${icon('plus')}</summary><ul class="care-list">${product.care.map((c) => `<li>${e(c)}</li>`).join('')}</ul><p class="muted small">${e(product.colorNote)}</p></details>
          <details><summary>Shipping & delivery ${icon('plus')}</summary><p><strong>Shipping time:</strong> ${e(product.delivery.estimate || 'Confirmed on Instagram')}.</p><p>${e(product.delivery.preparation)}</p><p>${e(product.delivery.note)}</p><p class="shipping-included-note">Shipping is included in the total shown. There is no separate shipping payment on this website.</p></details>
        </div>
      </section>
    </div>
    ${orderForm(product, variant)}
    <section class="product-bottom-note wrap"><p class="eyebrow">The BY RIDAH way</p><p>Take your time choosing. We’re here to help with the details.</p></section>
    <div class="mobile-order-bar" id="mobile-order-bar"><div><small>Shipping included</small><strong data-total>${formatMoney(totals.totalCents)}</strong></div><a class="button button-dark" href="#want-to-order">Prepare my order ${icon('arrow')}</a></div>
  </main>
  <dialog class="size-dialog" id="size-dialog" aria-labelledby="size-dialog-title"><div class="dialog-heading"><div><p class="eyebrow">Find your fit</p><h2 id="size-dialog-title">Size chart</h2></div><button type="button" class="icon-button" data-close-dialog aria-label="Close size chart">${icon('close')}</button></div><p class="muted">${e(product.name)} · ${e(product.fit)}</p><div class="size-dialog-toolbar"><div class="unit-toggle" role="group" aria-label="Measurement units"><button type="button" data-unit="in" class="is-active" aria-pressed="true">Inches</button><button type="button" data-unit="cm" aria-pressed="false">Centimeters</button></div><span>Garment measurements</span></div><div id="size-chart-content">${sizeChartTable(product)}</div><p class="size-chart-note">${e(product.sizeChart.note)}</p><p class="size-chart-help">${e(product.sizeChart.help || 'Prefer a second opinion? Send us your measurements on Instagram and we’ll help you choose.')}</p></dialog>
  <dialog class="lightbox" id="lightbox" aria-label="Larger product image"><button type="button" class="icon-button lightbox-close" data-close-dialog aria-label="Close larger image">${icon('close')}</button><img id="lightbox-image" src="${e(initialImage.full || initialImage.src)}" alt="${e(initialImage.alt)}" width="960" height="960"><div class="lightbox-footer"><button type="button" class="icon-button" id="lightbox-prev" aria-label="Previous image">${icon('chevron')}</button><span id="lightbox-caption">${e(variant.name)}</span><button type="button" class="icon-button" id="lightbox-next" aria-label="Next image">${icon('chevron')}</button></div></dialog>`;
}

export function dialogs() {
  return `<dialog class="search-dialog" id="search-dialog" aria-labelledby="search-dialog-title"><div class="dialog-heading"><h2 id="search-dialog-title">Find your piece.</h2><button type="button" class="icon-button" data-close-dialog aria-label="Close search">${icon('close')}</button></div><label class="search-dialog-input">${icon('search')}<span class="sr-only">Search by product, category, or keyword</span><input type="search" id="global-search" placeholder="Try “hoodie”, “shawl”, or “dresses”" autocomplete="off"></label><div class="search-suggestions"><span>Try</span>${['Hoodie dress', 'Shawl', 'Mesh dress', 'Two-piece set', 'Dresses'].map((q) => `<button type="button" data-search-suggestion="${e(q)}">${e(q)}</button>`).join('')}</div><p class="result-count" id="search-result-count" role="status"></p><div id="search-results" class="search-results"></div></dialog>
  <dialog class="manual-copy-dialog" id="manual-copy-dialog" aria-labelledby="manual-copy-title"><div class="dialog-heading"><h2 id="manual-copy-title">Copy your order</h2><button type="button" class="icon-button" data-close-dialog aria-label="Close manual copy">${icon('close')}</button></div><p>Your browser couldn’t copy automatically. Select the text below and copy it, then paste it into your Instagram chat with us.</p><label class="sr-only" for="manual-copy-text">Order details to copy</label><textarea id="manual-copy-text" readonly rows="12"></textarea><div class="manual-copy-actions"><button type="button" class="button button-outline" id="select-copy-text">Select all text</button><button type="button" class="button button-dark" id="confirm-manual-copy">I’ve copied it ${icon('check')}</button></div></dialog>
  <div class="toast" id="toast" role="status" aria-live="polite" hidden>${icon('check')}<span></span></div>`;
}
